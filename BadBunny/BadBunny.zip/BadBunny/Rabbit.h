//
//  Rabbit.h
//  BadBunny
//
//  Created by Jenna Wang on 4/5/23.
//

#ifndef rabbit_h
#define rabbit_h

class Arena;

class Rabbit
{
  public:
      // Constructor
    Rabbit(Arena* ap, int r, int c);

      // Accessors
    int  row() const;
    int  col() const;
    bool isDead() const;

      // Mutators
    void move();

  private:
    Arena* m_arena;
    int    m_row;
    int    m_col;
    int    m_health;
    int    m_idleTurnsRemaining;
};

#endif // rabbit_h
